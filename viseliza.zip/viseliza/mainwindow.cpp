#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QMessageBox>
#include <QDebug>
#include <QRandomGenerator>
#include <QFont>
#include <QPalette>
#include <QPixmap>
#include <QCoreApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , dbManager(new DatabaseManager(this))
    , totalWins(0), level(1), twoPlayersMode(false)
{
    ui->setupUi(this);
    
    if (!dbManager->initializeDatabase()) {
        QMessageBox::critical(this, "Ошибка!", "не удалось инициализировать базу данных :(");
    }
    
    setupStyledButtons();
    createLetterButtons();
    setupBackgrounds();
    resetGame();

    connect(ui->returnToMenuButton_2, &QPushButton::clicked, this, &MainWindow::on_returnToMenuButton_clicked);
    connect(ui->winReturnToMenuButton, &QPushButton::clicked, this, &MainWindow::on_returnToMenuButton_clicked);
    connect(ui->loseReturnToMenuButton, &QPushButton::clicked, this, &MainWindow::on_returnToMenuButton_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupStyledButtons()
{
    QString buttonStyle = "QPushButton {"
                          "background-color: #4CAF50;"
                          "border: none;"
                          "color: white;"
                          "padding: 10px 24px;"
                          "text-align: center;"
                          "font-size: 16px;"
                          "margin: 4px 2px;"
                          "border-radius: 8px;"
                          "}"
                          "QPushButton:hover {"
                          "background-color: #45a049;"
                          "}"
                          "QPushButton:pressed {"
                          "background-color: #3e8e41;"
                          "}";

    QList<QPushButton*> buttons = findChildren<QPushButton*>();
    foreach(QPushButton* button, buttons) {
        button->setStyleSheet(buttonStyle);
    }
}

void MainWindow::createLetterButtons()
{
    QString letters = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
    int row = 0;
    int col = 0;
    const int maxCols = 8;

    QLayoutItem* item;
    while ((item = ui->lettersLayout->takeAt(0)) != nullptr) {
        delete item->widget();
        delete item;
    }
    letterButtons.clear();

    int buttonWidth = 45;
    int buttonHeight = 45;

    for (const QChar &letter : letters) {
        QPushButton *button = new QPushButton(letter, this);
        button->setFixedSize(buttonWidth, buttonHeight);
        button->setStyleSheet("QPushButton {"
                            "background-color: #4CAF50;"
                            "border: none;"
                            "color: white;"
                            "text-align: center;"
                            "font-size: 16px;"
                            "font-weight: bold;"
                            "margin: 2px;"
                            "border-radius: 4px;"
                            "}"
                            "QPushButton:hover {"
                            "background-color: #45a049;"
                            "}"
                            "QPushButton:pressed {"
                            "background-color: #3e8e41;"
                            "}"
                            "QPushButton:disabled {"
                            "background-color: #cccccc;"
                            "color: #666666;"
                            "}");
        connect(button, &QPushButton::clicked, [this, button]() {
            QString letter = button->text();
            button->setEnabled(false);

            bool found = false;
            for (int i = 0; i < currentWord.length(); ++i) {
                if (currentWord[i] == letter[0]) {
                    displayedWord[i] = letter[0];
                    found = true;
                }
            }

            if (!found) {
                lives--;
                updateDisplay();
            } else {
                updateDisplay();
            }

            if (displayedWord == currentWord) {
                showWinScreen();
            } else if (lives <= 0) {
                showLoseScreen();
            }
        });
        ui->lettersLayout->addWidget(button, row, col);
        letterButtons.append(button);

        col++;
        if (col >= maxCols) {
            col = 0;
            row++;
        }
    }
}

void MainWindow::setupBackgrounds()
{
    struct BackgroundInfo {
        QWidget* screen;
        QString labelName;
        QString imagePath;
    };

    QVector<BackgroundInfo> backgrounds = {
        {ui->mainMenu, "mainMenuBackground", ":/image/main_menu_background.jpg"},
        {ui->modeSelectScreen, "modeSelectBackground", ":/image/mode_select_background.jpg"},
        {ui->themeSelectScreen, "themeSelectBackground", ":/image/theme_select_background.jpg"},
        {ui->gameScreen, "gameScreenBackground", ":/image/game_screen_background.jpg"},
        {ui->winScreen, "winScreenBackground", ":/image/win_screen_background.jpg"},
        {ui->loseScreen, "loseScreenBackground", ":/image/lose_screen_background.jpg"},
        {ui->customWordScreen, "customWordBackground", ":/image/custom_word_background.jpg"}
    };

    for (const auto& bg : backgrounds) {
        QLabel* backgroundLabel = bg.screen->findChild<QLabel*>(bg.labelName);
        if (backgroundLabel) {
            QPixmap pixmap(bg.imagePath);
            if (!pixmap.isNull()) {
                backgroundLabel->setPixmap(pixmap.scaled(backgroundLabel->size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
                backgroundLabel->lower();
            } else {
                qDebug() << "Не удалось загрузить изображение:" << bg.imagePath;
            }
        } else {
            qDebug() << "Не удалось найти QLabel с именем:" << bg.labelName;
        }
    }
}

void MainWindow::startGame()
{
    if (currentWord.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Не удалось получить слово для игры!");
        ui->stackedWidget->setCurrentWidget(ui->themeSelectScreen);
        return;
    }
    
    displayedWord = QString(currentWord.length(), '_');
    lives = 7;
    
    ui->labelTheme->setText("Тема: " + theme);
    ui->labelLevel->setText("Уровень: " + QString::number(level));
    ui->labelLettersCount->setText("Букв: " + QString::number(currentWord.length()));
    
    for (int i = 1; i <= 7; ++i) {
        QLabel* heart = findChild<QLabel*>(QString("heart%1").arg(i));
        if (heart) {
            heart->setPixmap(QPixmap(":/image/heart1.png"));
            heart->setVisible(true);
            heart->setScaledContents(true);
            heart->setFixedSize(40, 40);
        }
    }
    
    for (QPushButton *button : letterButtons) {
        button->setEnabled(true);
        button->setStyleSheet("QPushButton {"
                            "background-color: #4CAF50;"
                            "border: none;"
                            "color: white;"
                            "text-align: center;"
                            "font-size: 16px;"
                            "font-weight: bold;"
                            "margin: 2px;"
                            "border-radius: 4px;"
                            "}"
                            "QPushButton:hover {"
                            "background-color: #45a049;"
                            "}"
                            "QPushButton:pressed {"
                            "background-color: #3e8e41;"
                            "}"
                            "QPushButton:disabled {"
                            "background-color: #cccccc;"
                            "color: #666666;"
                            "}");
    }
    
    ui->stackedWidget->setCurrentWidget(ui->gameScreen);
    
    updateDisplay();
}

void MainWindow::updateDisplay()
{
    QString spacedWord;
    for (int i = 0; i < displayedWord.length(); ++i) {
        spacedWord += displayedWord[i];
        if (i < displayedWord.length() - 1) {
            spacedWord += " ";
        }
    }
    
    QFont wordFont = ui->labelWord->font();
    wordFont.setPointSize(24);
    wordFont.setBold(true);
    ui->labelWord->setFont(wordFont);
    ui->labelWord->setText(spacedWord);
    
    ui->labelLives->setText(QString("Жизни: %1").arg(lives));
    
    for (int i = 1; i <= 7; ++i) {
        QLabel* heart = findChild<QLabel*>(QString("heart%1").arg(i));
        if (heart) {
            if (i <= lives) {
                heart->setPixmap(QPixmap(":/image/heart1.png"));
                heart->setVisible(true);
            } else {
                heart->setPixmap(QPixmap(":/image/heart2.png"));
                heart->setVisible(true);
            }
        }
    }
}

void MainWindow::showWinScreen()
{
    foreach(QPushButton* button, letterButtons) {
        button->hide();
    }

    totalWins++;
    themeWins[theme]++;

    if (totalWins % 3 == 0) {
        level++;
    }

    ui->stackedWidget->setCurrentWidget(ui->winScreen);
    ui->labelWinMessage->setText("Вы выиграли!\nУровень: " + QString::number(level));
    updateStats();
}

void MainWindow::showLoseScreen()
{
    foreach(QPushButton* button, letterButtons) {
        button->hide();
    }

    ui->stackedWidget->setCurrentWidget(ui->loseScreen);
    ui->labelLoseMessage->setText("Уровень: " + QString::number(level));
    ui->labelCorrectWord->setText("Загаданное слово:\n" + currentWord);
    updateStats();
}

void MainWindow::updateStats()
{
    QString statsText = QString("Статистика:\n"
                                "Уровень: %1\n"
                                "Всего побед: %2\n\n"
                                "Побед по темам:\n")
                            .arg(level)
                            .arg(totalWins);

    for (auto it = themeWins.begin(); it != themeWins.end(); ++it) {
        statsText += it.key() + ": " + QString::number(it.value()) + "\n";
    }

    ui->labelStats->setText(statsText);
}

void MainWindow::resetGame()
{
    currentWord.clear();
    displayedWord.clear();
    lives = 7;
    
    for (QPushButton *button : letterButtons) {
        button->setEnabled(true);
        button->setStyleSheet("QPushButton {"
                            "background-color: #4CAF50;"
                            "border: none;"
                            "color: white;"
                            "text-align: center;"
                            "font-size: 16px;"
                            "font-weight: bold;"
                            "margin: 2px;"
                            "border-radius: 4px;"
                            "}"
                            "QPushButton:hover {"
                            "background-color: #45a049;"
                            "}"
                            "QPushButton:pressed {"
                            "background-color: #3e8e41;"
                            "}"
                            "QPushButton:disabled {"
                            "background-color: #cccccc;"
                            "color: #666666;"
                            "}");
    }
    
    ui->stackedWidget->setCurrentWidget(ui->mainMenu);
    updateStats();
}

void MainWindow::on_playButton_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->modeSelectScreen);
}

void MainWindow::on_exitButton_clicked()
{
    QApplication::quit();
}

void MainWindow::on_singlePlayerButton_clicked()
{
    twoPlayersMode = false;
    ui->stackedWidget->setCurrentWidget(ui->themeSelectScreen);
    
    QLayoutItem* item;
    while ((item = ui->themesLayout->takeAt(0)) != nullptr) {
        delete item->widget();
        delete item;
    }
    
    QStringList categories = dbManager->getCategories();
    for (const QString &category : categories) {
        QPushButton *button = new QPushButton(category, this);
        button->setProperty("theme", category);
        button->setStyleSheet("QPushButton {"
                            "background-color: #4CAF50;"
                            "border: none;"
                            "color: white;"
                            "padding: 10px 24px;"
                            "text-align: center;"
                            "font-size: 16px;"
                            "margin: 4px 2px;"
                            "border-radius: 8px;"
                            "}"
                            "QPushButton:hover {"
                            "background-color: #45a049;"
                            "}"
                            "QPushButton:pressed {"
                            "background-color: #3e8e41;"
                            "}");
        connect(button, &QPushButton::clicked, this, &MainWindow::on_themeSelected);
        ui->themesLayout->addWidget(button);
    }
}

void MainWindow::on_twoPlayersButton_clicked()
{
    twoPlayersMode = true;
    ui->stackedWidget->setCurrentWidget(ui->customWordScreen);
    
    ui->customWordInput->clear();
    ui->customThemeInput->clear();
}

void MainWindow::on_startGameButton_clicked()
{
    if (twoPlayersMode) {
        currentWord = ui->customWordInput->text().toUpper();
        QString customTheme = ui->customThemeInput->text();
        
        if (currentWord.isEmpty()) {
            QMessageBox::warning(this, "Предупреждение", "Введите слово!");
            return;
        }
        if (customTheme.isEmpty()) {
            QMessageBox::warning(this, "Предупреждение", "Введите тематику слова!");
            return;
        }
        
        theme = customTheme;
    } else {
        currentWord = getRandomWordFromCategory(theme);
    }
    
    startGame();
}

QString MainWindow::getRandomWordFromCategory(const QString &category)
{
    QStringList words = dbManager->getWordsByCategory(category);
    if (words.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "В выбранной категории нет слов!");
        return QString();
    }
    return words[QRandomGenerator::global()->bounded(words.size())];
}

void MainWindow::on_guessButton_clicked()
{
    QString guess = ui->lineEditGuess->text().toUpper();
    if (guess.isEmpty() || guess.length() != 1) return;

    bool correct = false;
    for (int i = 0; i < currentWord.length(); ++i) {
        if (currentWord[i] == guess[0]) {
            displayedWord[i] = guess[0];
            correct = true;
        }
    }

    if (!correct) {
        lives--;
    }

    ui->lineEditGuess->clear();
    updateDisplay();

    if (displayedWord == currentWord) {
        showWinScreen();
    } else if (lives <= 0) {
        showLoseScreen();
    }
}

void MainWindow::on_returnToMenuButton_clicked()
{
    currentWord.clear();
    displayedWord.clear();
    lives = 7;
    
    for (QPushButton *button : letterButtons) {
        button->setEnabled(true);
        button->show();
        button->setStyleSheet("QPushButton {"
                            "background-color: #4CAF50;"
                            "border: none;"
                            "color: white;"
                            "text-align: center;"
                            "font-size: 16px;"
                            "font-weight: bold;"
                            "margin: 2px;"
                            "border-radius: 4px;"
                            "}"
                            "QPushButton:hover {"
                            "background-color: #45a049;"
                            "}"
                            "QPushButton:pressed {"
                            "background-color: #3e8e41;"
                            "}"
                            "QPushButton:disabled {"
                            "background-color: #cccccc;"
                            "color: #666666;"
                            "}");
    }
    
    ui->stackedWidget->setCurrentWidget(ui->mainMenu);
    updateStats();
}

void MainWindow::on_themeSelected()
{
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if (button) {
        theme = button->property("theme").toString();
        currentWord = getRandomWordFromCategory(theme);
        startGame();
    }
}

void MainWindow::on_letterButton_clicked()
{
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if (!button) return;

    QString letter = button->text();
    button->setEnabled(false);

    bool found = false;
    for (int i = 0; i < currentWord.length(); ++i) {
        if (currentWord[i] == letter[0]) {
            displayedWord[i] = letter[0];
            found = true;
        }
    }

    if (!found) {
        lives--;
        updateDisplay();
    } else {
        updateDisplay();
    }

    if (displayedWord == currentWord) {
        showWinScreen();
    } else if (lives <= 0) {
        showLoseScreen();
    }
}

void MainWindow::on_customWordInput_textChanged(const QString &text)
{
    if (!text.isEmpty()) {
        QString upperText = text.toUpper();
        if (text != upperText) {
            ui->customWordInput->setText(upperText);
        }
    }
}

void MainWindow::on_customThemeInput_textChanged(const QString &text)
{
    if (!text.isEmpty()) {
        QString formattedText = text;
        formattedText[0] = formattedText[0].toUpper();
        if (text != formattedText) {
            ui->customThemeInput->setText(formattedText);
        }
    }
}
