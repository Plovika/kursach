#include "databasemanager.h"

DatabaseManager::DatabaseManager(QObject *parent) : QObject(parent)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("words.db");
}

DatabaseManager::~DatabaseManager()
{
    if (db.isOpen()) {
        db.close();
    }
}

bool DatabaseManager::initializeDatabase()
{
    if (!db.open()) {
        qDebug() << "Error: Failed to open database:" << db.lastError().text();
        return false;
    }

    createTables();
    insertInitialData();
    return true;
}

void DatabaseManager::createTables()
{
    QSqlQuery query;
    
    query.exec("CREATE TABLE IF NOT EXISTS categories ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "name TEXT UNIQUE NOT NULL)");

    query.exec("CREATE TABLE IF NOT EXISTS words ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "word TEXT NOT NULL,"
               "category_id INTEGER,"
               "FOREIGN KEY (category_id) REFERENCES categories(id))");
}

void DatabaseManager::insertInitialData()
{
    QSqlQuery query;
    
    QStringList categories = {"Животные", "Еда", "Растения", "Спорт", "Профессии", "Страны", "Города"};
    for (const QString &category : categories) {
        query.prepare("INSERT OR IGNORE INTO categories (name) VALUES (?)");
        query.addBindValue(category);
        query.exec();
    }

    QMap<QString, QStringList> wordsByCategory = {
        {"Животные", {"КОШКА", "СОБАКА", "СЛОН", "ТИГР", "ЛЕВ", "ЖИРАФ", "ЗЕБРА", "ПАНДА", "МЕДВЕДЬ", "ВОЛК", "ГОЛУБИРОШПИОНИРО"}},
        {"Еда", {"ПИЦЦА", "СУП", "САЛАТ", "КАРТОШКА", "МЯСО", "РЫБА", "МАКАРОНЫ", "КАША", "БОРЩ", "ПЕЛЬМЕНИ"}},
        {"Растения", {"РОЗА", "ТЮЛЬПАН", "ДУБ", "БЕРЕЗА", "СОСНА", "РОМАШКА", "ЛИЛИЯ", "ОРЕХ", "КЛЕН", "ТОПОЛЬ"}},
        {"Спорт", {"ФУТБОЛ", "БАСКЕТБОЛ", "ВОЛЕЙБОЛ", "ТЕННИС", "ПЛАВАНИЕ", "БЕГ", "БОКС", "ХОККЕЙ", "ГИМНАСТИКА", "БОРЬБА"}},
        {"Профессии", {"ВРАЧ", "УЧИТЕЛЬ", "ИНЖЕНЕР", "ПРОГРАММИСТ", "АКТЕР", "ПОВАР", "ПОЛИЦЕЙСКИЙ", "ПИЛОТ", "АРХИТЕКТОР", "ЖУРНАЛИСТ"}},
        {"Страны", {"РОССИЯ", "ГЕРМАНИЯ", "ФРАНЦИЯ", "ИТАЛИЯ", "ИСПАНИЯ", "КИТАЙ", "ЯПОНИЯ", "БРАЗИЛИЯ", "КАНАДА", "АВСТРАЛИЯ"}},
        {"Города", {"МОСКВА", "ПЕТЕРБУРГ", "НОВОСИБИРСК", "ЕКАТЕРИНБУРГ", "КАЗАНЬ", "ЧЕЛЯБИНСК", "СОЛНЕЧНОГОРСК","ОМСК", "САМАРА", "РОСТОВ", "ВОРОНЕЖ", "МИЛЛЕРОВО", "КРАСНОГОРСК","УЛЬЯНОВСК"}}
    };

    for (auto it = wordsByCategory.begin(); it != wordsByCategory.end(); ++it) {
        QString category = it.key();
        QStringList words = it.value();

        query.prepare("SELECT id FROM categories WHERE name = ?");
        query.addBindValue(category);
        query.exec();
        
        if (query.next()) {
            int categoryId = query.value(0).toInt();
            
            for (const QString &word : words) {
                query.prepare("INSERT OR IGNORE INTO words (word, category_id) VALUES (?, ?)");
                query.addBindValue(word);
                query.addBindValue(categoryId);
                query.exec();
            }
        }
    }
}

QStringList DatabaseManager::getWordsByCategory(const QString &category)
{
    QStringList words;
    QSqlQuery query;
    
    query.prepare("SELECT w.word FROM words w "
                 "JOIN categories c ON w.category_id = c.id "
                 "WHERE c.name = ?");
    query.addBindValue(category);
    
    if (query.exec()) {
        while (query.next()) {
            words << query.value(0).toString();
        }
    }
    
    return words;
}

QStringList DatabaseManager::getCategories()
{
    QStringList categories;
    QSqlQuery query("SELECT name FROM categories ORDER BY name");
    
    while (query.next()) {
        categories << query.value(0).toString();
    }
    
    return categories;
}

bool DatabaseManager::addWord(const QString &word, const QString &category)
{
    QSqlQuery query;
    
    query.prepare("SELECT id FROM categories WHERE name = ?");
    query.addBindValue(category);
    query.exec();
    
    if (query.next()) {
        int categoryId = query.value(0).toInt();
        
        query.prepare("INSERT INTO words (word, category_id) VALUES (?, ?)");
        query.addBindValue(word.toUpper());
        query.addBindValue(categoryId);
        return query.exec();
    }
    
    return false;
}

bool DatabaseManager::removeWord(const QString &word, const QString &category)
{
    QSqlQuery query;
    
    query.prepare("DELETE FROM words WHERE word = ? AND category_id IN "
                 "(SELECT id FROM categories WHERE name = ?)");
    query.addBindValue(word.toUpper());
    query.addBindValue(category);
    
    return query.exec();
} 
