#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QStringList>
#include <QMap>
#include <QPushButton>
#include "databasemanager.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_playButton_clicked();
    void on_exitButton_clicked();
    void on_singlePlayerButton_clicked();
    void on_twoPlayersButton_clicked();
    void on_startGameButton_clicked();
    void on_guessButton_clicked();
    void on_returnToMenuButton_clicked();
    void on_themeSelected();
    void on_letterButton_clicked();
    void on_customWordInput_textChanged(const QString &text);
    void on_customThemeInput_textChanged(const QString &text);

private:
    Ui::MainWindow *ui;
    DatabaseManager *dbManager;
    QString currentWord;
    QString displayedWord;
    QString theme;
    int lives;
    int totalWins;
    int level;
    QMap<QString, int> themeWins;
    QVector<QPushButton*> letterButtons;
    bool twoPlayersMode;

    void startGame();
    void updateDisplay();
    void showWinScreen();
    void showLoseScreen();
    void resetGame();
    void createLetterButtons();
    void updateStats();
    void setupStyledButtons();
    void setupBackgrounds();
    QString getRandomWordFromCategory(const QString &category);
};

#endif // MAINWINDOW_H
