#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QStringList>
#include <QDebug>

class DatabaseManager : public QObject
{
    Q_OBJECT

public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager();

    bool initializeDatabase();
    QStringList getWordsByCategory(const QString &category);
    QStringList getCategories();
    bool addWord(const QString &word, const QString &category);
    bool removeWord(const QString &word, const QString &category);

private:
    QSqlDatabase db;
    void createTables();
    void insertInitialData();
};

#endif // DATABASEMANAGER_H 